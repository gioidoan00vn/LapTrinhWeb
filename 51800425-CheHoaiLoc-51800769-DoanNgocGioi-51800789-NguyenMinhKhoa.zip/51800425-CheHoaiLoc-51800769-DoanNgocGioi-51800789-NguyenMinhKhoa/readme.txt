Tên đề tài: Xây dựng hệ thống học tập online qua mạng dưới nền tảng Website

Thành viên nhóm:
1. Đoàn Ngọc Giỏi - mssv: 51800769
2. Chế Hoài Lộc - mssv: 51800425
3. Nguyễn Minh Khoa - mssv: 51800789

Cách cài đặt để chạy website:
1. Mở localhost/phpmyadmin và nạp dữ liệu database từ file: database.sql
2. Tạo folder tên là classroom ở trong thư mục htdocs của Xampp
3. copy tất cả các tập tin trong folder source-code vào folder classroom tạo ở bước 2
4. khởi chạy xampp và chọn start apache và mySQL
5. Vào brower và mở đường dẫn localhost/classrom để chạy

Một số tài khoản để login vào Website:
1. Tài khoản admin
email:Gioi@gmai.com
password: 123456
2. Tài khoản giáo viên
email: Toan@gmail.com
password: 123456
3. Tài khoản học viên
email: Hoang@gmail.com
password: 123456

Ngoài ra một số account khác có thể vào phần bảng user của database để sử dụng. Tất cả các account đều sử dụng password là 123456

Phân công:
* Bạn Nguyễn Minh Khoa làm phần giao diện bao gồm (login,home, steam_class,..) và một số chức năng như: login, reset password qua mail, thêm lớp vào database
* Bạn Đoàn Ngọc Giỏi và Chế Hoài Lộc cùng nhau làm những phần còn lại: logout, hiển thị danh sách học viên, hiển thị các khối lớp, thêm lớp học, đăng kí vào lớp học, hiển thị thông tin từ database lên Steam_class, và các vấn đề còn lại

